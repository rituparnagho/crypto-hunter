// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDI-UtrN9mpjSLBvix3inJR6dZjlf9N2nM",
  authDomain: "crypto-hunter-3e703.firebaseapp.com",
  projectId: "crypto-hunter-3e703",
  storageBucket: "crypto-hunter-3e703.appspot.com",
  messagingSenderId: "1045600126355",
  appId: "1:1045600126355:web:df9b4ca109fcc4deb41466",
};

export default firebaseConfig;
